import { useState } from "react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

// 題庫資料略（請補充完整）...

export default function HomeAdventureGame() {
  return (
    <div className="min-h-screen bg-pink-50 flex items-center justify-center">
      <h1 className="text-3xl font-bold text-pink-600">Hello, 家鄉大冒險！</h1>
    </div>
  );
}
